﻿// MainWindow.xaml.cs
using System;
using System.Windows;
using System.Windows.Controls;

namespace SiyaWpfCalculator
{
    public partial class MainWindow : Window
    {
        private double memoryValue = 0;
        private string operation = "";
        private bool isNewNumber = true;

        public MainWindow()
        {
            InitializeComponent();
        }

        // Handles the button click for numeric buttons (0-9)
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Button button = (Button)sender;

            if (isNewNumber)
            {
                Display.Text = button.Content.ToString();
                isNewNumber = false;
            }
            else
            {
                Display.Text += button.Content.ToString();
            }
        }

        // Handles the button click for operator buttons (+, -, *, /)
        private void Operator_Click(object sender, RoutedEventArgs e)
        {
            Button button = (Button)sender;
            operation = button.Content.ToString();
            memoryValue = double.Parse(Display.Text);
            isNewNumber = true;
        }

        // Handles the button click for memory operation buttons (M+, M-, MR)
        private void MemoryOperation_Click(object sender, RoutedEventArgs e)
        {
            Button button = (Button)sender;

            switch (button.Content.ToString())
            {
                case "M+":
                    memoryValue += double.Parse(Display.Text);
                    break;
                case "M-":
                    memoryValue -= double.Parse(Display.Text);
                    break;
                case "MR":
                    Display.Text = memoryValue.ToString();
                    isNewNumber = true;
                    break;
            }
        }

        // Handles the button click for clear operation button (C)
        private void Clear_Click(object sender, RoutedEventArgs e)
        {
            Display.Text = "0";
            isNewNumber = true;
        }

        // Handles the button click for equal operation button (=)
        private void Equal_Click(object sender, RoutedEventArgs e)
        {
            double currentNumber = double.Parse(Display.Text);

            switch (operation)
            {
                case "+":
                    Display.Text = (memoryValue + currentNumber).ToString();
                    break;
                case "-":
                    Display.Text = (memoryValue - currentNumber).ToString();
                    break;
                case "*":
                    Display.Text = (memoryValue * currentNumber).ToString();
                    break;
                case "/":
                    if (currentNumber != 0)
                        Display.Text = (memoryValue / currentNumber).ToString();
                    else
                        Display.Text = "Error";
                    break;
            }

            isNewNumber = true;
        }
    }
}
